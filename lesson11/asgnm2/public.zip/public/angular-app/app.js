angular.module("meanGames", ["ngRoute"]).config(config).run;

function config($routeProvider, $locationProvider) {
    $locationProvider.hashPrefix("");
    $routeProvider.when("/", {
        templateUrl: "angular-app/game-list/game-list.html",
        controller: "GamesController",
        controllerAs: "vm"
    }).when("/game/:id", {
        templateUrl: "angular-app/game-one/game-one.html",
        controller: "GameController",
        controllerAs: "vm"
    }).when("/register", {
        templateUrl: "angular-app/register/register.html",
        controller: "RegisterController",
        controllerAs: "vm",
        // access: { restricted: true }
    }).when("/profile", {
        templateUrl: "angular-app/profile/profile.html",
        controller: "ProfileController",
        controllerAs: "vm",
        access: { restricted: true }
    })

}

function run($rootScope, $location) {
    $rootScope.$on("$routeChangedStart", function(event, nextRoute, currentRoute) {
        if (nextRoute.access !== undefined & nextRoute.access.restricted) {
            $location.path("/");
        }
    })

}