angular.module("meanGames").factory("AutchFactory", AutchFactory);

function AutchFactory() {
    var auth = { isLoggedIn: false }
    return {
        auth: auth
    };



}