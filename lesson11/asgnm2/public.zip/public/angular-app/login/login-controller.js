angular.module("meanGames").controller("LoginController", LoginController)

function LoginController($location, $window, AutchFactory, UserDataFactory) {
    const vm = this;
    vm.isActiveTab = function(url) {
        const currentPath = $location.path().split("/")[1];
        (url === currentPath) ? "active" : "";
    }
    vm.isLoggedIn = function() {
        if (AutchFactory.auth.isLoggedIn) {
            return true;
        } else {
            return false;
        }
    }
    vm.login = function() {
        if (vm.username && vm.password) {
            const user = {
                username: vm.username,
                password: vm.password
            };
            UserDataFactory.login(user).then((response) => {
                console.log(response);
                if (response && response.success) {
                    $window.sessionStorage.token = response.token;
                    AutchFactory.auth.isLoggedIn = true;
                    vm.username = "";
                    vm.password = "";
                    $location.path("/");
                }
            }).catch((err) => {
                console.log(err);
                console.log("adssda");
            })
        }
    }
    vm.logout = function() {
        AutchFactory.auth.isLoggedIn = false;
        delete $window.sessionStorage.token;
        $location.path("/");

    }
}