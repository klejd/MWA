angular.module("meanGames").controller("ProfileController", ProfileController);

function ProfileController($window) {
    if ($window.sessionStorage.token == false) {
        $location.path("/");
    }
}